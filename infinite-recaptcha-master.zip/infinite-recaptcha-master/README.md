# recaptcha prank

reCAPTCHA look-alike which is impossible to complete. it goes forever!

## demo video

https://github.com/rj1/recaptcha-prank/assets/83531587/9e63a26d-a3b1-4e1e-87ba-ea7681923a9c
